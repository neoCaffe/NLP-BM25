''' COVID_bm01.py '''
from rank_bm25 import BM25Okapi
import pandas as pd
import os
import sumy
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer as sumyToken
from sumy.summarizers.lsa import LsaSummarizer
import numpy as np
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from PIL import Image

#--- make summary ---    
def mkSummText(content):
    # Initializing the parser
    my_parser = PlaintextParser.from_string(content, sumyToken('english'))
    # Creating a summary of 3 sentences
    lsa_summarizer = LsaSummarizer()
    Extract = lsa_summarizer(my_parser.document,sentences_count=3)
   
    conclusion = []
    for sentence in Extract:
        #print(sentence)
        conclusion.append(str(sentence))
                 
    return conclusion

#--- make wordcloud 
def mkCloud(txt):
    mask = np.array(Image.open('airplane3.png')) 
    font = 'SourceHanSansTW-Regular.otf'
        
    cloud = WordCloud(background_color='white',mask=mask,font_path=font,
                      contour_width=3, contour_color='steelblue').generate(txt)
     
    plt.imshow(cloud)
    plt.axis("off")
    plt.show()
    # keywords 已經完成排序的 一個 dict                
    keywords = cloud.words_

    mostly = list(keywords.keys())
       
    print('Top10 keywords: ',mostly[:10])   
    mostkeys = str(mostly[:10])
  
    # 將wordcloud 存檔
    destFile = 'covidFig.jpg'
    cloud.to_file(destFile)
       
    # show image on screen
    if os.path.exists(destFile):
        img = Image.open(destFile, 'r')
        img.show()
         
''' main flow '''        
# load csv file
# https://www.kaggle.com/allen-institute-for-ai/CORD-19-research-challenge?select=metadata.csv
df = pd.read_csv('COVID_metadata.csv',dtype=object)

mtitle   = df['title'].astype(str)
mabs     = df['abstract'].astype(str)
murl     = df['url'].astype(str) 
mpubtime = df['publish_time'].astype(str)
mpmcid   = df['pmcid'].astype(str)
mauthor  = df['authors'].astype(str)
mjournal = df['journal'].astype(str)
mdoi     = df['doi'].astype(str)

#--- tokenize
tokenized_corpus = [doc.split(" ") for doc in mabs]

#--- initiate 
bm = BM25Okapi(tokenized_corpus)

# query --> 要查詢的 字詞
query = "Taiwan COVID vaccine"
tokenized_query = query.split(" ")

# 計算 BM25 score (log)
scores = bm.get_scores(tokenized_query)
# sort scores (take index)
s1 = np.argsort(scores)
sidx = s1[::-1]   # reverse s1
#print(sidx[:5])   # top 5 highest score papers 
fw = open('COVID_result.txt','w',encoding='utf-8')
for i in range(5):
    no = sidx[i]
    tmp =       f'Location: {no}\n'
    tmp = tmp + f'BM25 score: {scores[no]}\n'
    tmp = tmp + f'Title: {mtitle[no]}\n'
    tmp = tmp + f'Authors: {mauthor[no]}\n'
    tmp = tmp + f'PubTime: {mpubtime[no]}\n'
    tmp = tmp + f'Abstract: {mabs[no][:300]}\n'   
    tmp = tmp + f'Journal: {mjournal[no]}\n'
    tmp = tmp + f'URL: {murl[no]}\n'
    tmp = tmp + f'pmcid: {mpmcid[no]}\n'
    tmp = tmp + f'doi: {mdoi[no]}\n\n'
    print(tmp)
    print(tmp,file=fw)
    
fw.close()    

cordTxt = mabs[sidx[0]] 
#--- make wordcloud
mkCloud(cordTxt)
   

#-- make summary
print('----------------------------')
sumTxt = mkSummText(cordTxt)
f2 = open('Top1Summary.txt','w',encoding='utf-8') 
for s in sumTxt:
    print('>> ',s,file=f2)
    print('>> ',s) 
    
f2.close()
    


