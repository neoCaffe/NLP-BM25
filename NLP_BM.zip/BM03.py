''' BM03.py '''
from rank_bm25 import BM25Okapi
import pandas as pd
import os
#--- NLP summarize lib
import sumy
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer as sumyToken
from sumy.summarizers.lsa import LsaSummarizer
#--- wordcloud
import numpy as np
import matplotlib.pyplot as plt
from wordcloud import WordCloud
from PIL import Image

#--- make summary ---    
def mkSummText(content):
    # Initializing the parser
    my_parser = PlaintextParser.from_string(content, sumyToken('english'))
    # Creating a summary of 3 sentences
    lsa_summarizer = LsaSummarizer()
    Extract = lsa_summarizer(my_parser.document,sentences_count=3)
   
    conclusion = []
    for sentence in Extract:
        #print(sentence)
        conclusion.append(str(sentence))
                 
    return conclusion

#--- make wordcloud 
def mkCloud(txt):
    mask = np.array(Image.open('alice_mask.png')) 
    font = 'SourceHanSansTW-Regular.otf'
        
    cloud = WordCloud(background_color='white',mask=mask,font_path=font,
                      contour_width=3, contour_color='steelblue').generate(txt)
     
    plt.imshow(cloud)
    plt.axis("off")
    plt.show()
    # keywords 已經完成排序的 一個 dict                
    keywords = cloud.words_

    mostly = list(keywords.keys())
       
    print('Top10 keywords: ',mostly[:10])   
    mostkeys = str(mostly[:10])
    pmt = f'Top10 keywords in the text\n{mostkeys}'
    print(pmt)
 
    # 將wordcloud 存檔
    destFile = 'bmFig.jpg'
    cloud.to_file(destFile)
       
    # show image on screen
    if os.path.exists(destFile):
        img = Image.open(destFile, 'r')
        img.show()
         
''' main flow '''        
# load from csv 
df = pd.read_csv('movies.csv',dtype=object)

movies = df[['title','imdb_plot']]

mtitle = movies['title'].astype(str)
mimdb  = movies['imdb_plot'].astype(str) 

#--- tokenize
tokenized_corpus = [doc.split(" ") for doc in mimdb]

#--- initiate 
bm = BM25Okapi(tokenized_corpus)

# query --> 要查詢的 字詞
query = "musician "
tokenized_query = query.split(" ")

# 計算 BM25 score (log)
scores = bm.get_scores(tokenized_query)
idx = scores.argmax()

if idx != 0:
    print(f'idx: {idx}')
    print(scores[idx])
    print(mtitle[idx])
    imdbTxt = mimdb[idx]
    print(imdbTxt[:60])
    print(scores)
    print(len(scores))
    
#--- make wordcloud
mkCloud(imdbTxt)
   

#-- make summary
print('----------------------------')
sumTxt = mkSummText(imdbTxt)

for s in sumTxt:
    print('>> ',s)
    


